/**
 *  File :     main.c
 *  Date:      2015 Sep 26 15:38:38
 *  Author:    Tom Moxon
 *  Copyright: PatternAgents, LLC
 *
 *  DAVE_Workshop ARM CMSIS RTX RTOS & DSP Lab1
 *  <br>
 *  In the ARM RTX RTOS Lab, we will add two (2) ARM CMSIS APPs,
 *  namely the CMSIS_RTOS_RTX Library and the CMSIS DSP Digital Signal Processing Library.
 *  Using the CMSIS_RTOS_RTX Library we will create separate threads to blink the LEDs.
 *  <br>
 *
 */

/** Include Declarations from the DAVE Code Generator (i.e. the hardware platform) */
#include <DAVE.h>
#include "Dave/Generated/CMSIS_RTOS_RTX/INC/cmsis_os.h"
//#include "Dave/Generated/CMSIS_DSP/cmsis_dsp.h"
#include <stdio.h>

/* If you prefer to use functional names instead of DIGITAL_IO_, the just assign them below : */
#define LED1   DIGITAL_IO_0
#define LED2   DIGITAL_IO_1
#define SW1    DIGITAL_IO_2
#define SW2    DIGITAL_IO_3

/* ----------------------------------------------------------------------------------------*/
/* Helper Functions to map printf/scanf to UART_0 (USB CDC Communications Port             */
/* ----------------------------------------------------------------------------------------*/
/* This "wires" the stdio "putchar/printf" functions to transmit to UART_0 */
int _write(int file, uint8_t *buf, int nbytes)
{
    if(UART_Transmit(&UART_0, buf, nbytes) == UART_STATUS_SUCCESS) {
      while(UART_0.runtime->tx_busy) {
      }
    }
	return nbytes;
}
/* This "wires" the stdio "getchar" functions to receive from UART_0 */
int _read(int file, uint8_t *buf, int nbytes)
{
    if(UART_Receive(&UART_0, buf, nbytes) != UART_STATUS_SUCCESS) {
        while(UART_0.runtime->rx_busy) {
        }
    }
	return nbytes;
}
/* Initialize a text string for each UART APP                                                */
uint8_t UART0_mesg[]   = "UART_0: ";
uint8_t UART1_mesg[]   = "UART_1: ";
uint8_t hello_mesg[]   = "Hello!\r\n";
uint8_t newline_mesg[] = "\r\n";

/* define how many ADC channels we are using, and init the Adc_index */
#define ADC_CHANNELS 6
uint8_t Adc_index = (ADC_CHANNELS - 1);

/* define a detailed result structure for the ADC_MEASURMENT_0 APP instance */
typedef struct Adc_Measurement_struct
{
        uint8_t channel_num;
        uint8_t group_num;
        uint16_t conversion_result;
} Adc_Measurement_struct_t;
Adc_Measurement_struct_t Adc_Measurement[ADC_CHANNELS];

/* Flag for ADC measurement complete and valid ADC result */
bool adc_valid_result;

/* ADC_MEASURMENT_0 APP Interrupt Handler                 */
/* retrieves one ADC channel on each interrupt            */
void Adc_Measurement_Handler()
{
    uint32_t result;
    adc_valid_result = (bool)false;

    result = ADC_MEASUREMENT_GetDetailedResult(&ADC_MEASUREMENT_0);
    if((bool)(result >> VADC_GLOBRES_VF_Pos))
    {
       adc_valid_result = (bool)true;
       Adc_Measurement[Adc_index].channel_num = (result & VADC_GLOBRES_CHNR_Msk) >> VADC_GLOBRES_CHNR_Pos;
       Adc_Measurement[Adc_index].group_num = ADC_MEASUREMENT_Channel_A.group_index;
       Adc_Measurement[Adc_index].conversion_result = (result & VADC_GLOBRES_RESULT_Msk) >>
                            ((uint32_t)ADC_MEASUREMENT_0.iclass_config_handle->conversion_mode_standard * (uint32_t)2);
    }
    /* channels are the reverse order of what I thought, so count down, not up... */
    if (Adc_index == 0 ) {
    	Adc_index = (ADC_CHANNELS - 1);
    } else {
    	Adc_index--;
    }
}

/**
 * @brief thread_task_1(void const *args)
 *
 * <b>Details of function</b><br>
 * This thread will blink LED1.
 * <br>
 */
void thread_task_1(void const *args) {
  while (1) {
    DIGITAL_IO_ToggleOutput(&DIGITAL_IO_0);
    osDelay(500);
  }
}
osThreadDef(thread_task_1, osPriorityNormal, 1, 0);

/**
 * @brief thread_task_2(void const *args)
 *
 * <b>Details of function</b><br>
 * This thread will blink LED2.
 * <br>
 */
void thread_task_2(void const *args) {
	  while (1) {
	    DIGITAL_IO_ToggleOutput(&DIGITAL_IO_1);
	    osDelay(1000);
	  }
}
osThreadDef(thread_task_2, osPriorityNormal, 1, 0);

/**
 * @brief thread_task_3(void const *args)
 *
 * <b>Details of function</b><br>
 * This thread will blink DIGITAL_IO_0
 * <br>
 */
void thread_task_3(void const *args) {
	  while (1) {
	    // placeholder - does nothing right now...
	    osDelay(2000);
	  }
}
osThreadDef(thread_task_3, osPriorityNormal, 1, 0);

/**
 * @brief thread_task_4(void const *args)
 *
 * <b>Details of function</b><br>
 *    This thread will output to printf
  * <br>
 */
void thread_task_4(void const *args) {
  while (1) {
	printf("\r\n   Hello from ARM RTX RTOS Thread 4 !!! ");
	osDelay(3000);
  }
}
osThreadDef(thread_task_4, osPriorityAboveNormal, 1, 0);

/**
 * @brief main() - Application entry point
 *
 * <b>Details of function</b><br>
 * This routine is the application entry point, invoked by the device startup code.
 * <br>
 */
int main(void)
{
  /** Initialize the DAVE APPs (i.e. the hardware platform) and return status   */
  DAVE_STATUS_t status;
  status = DAVE_Init();
  if(status == DAVE_STATUS_FAILURE) {
    /* DAVE/XMCLib Run-Time Error Handler Code.                                 */
	/* The while loop below can be replaced with a user error handler.          */
	XMC_DEBUG("DAVE APPs initialization failed\n");
	while(1U) {
	  /* Infinite loop for failed initialization */
	  /* XMC_DEBUG("Dave's not here, man...\n"); */
	}
  } else {
	/* Successful start of the DAVE APPs, go on to running the user application */
	/* Place User Application Code below :                                      */
	/* Turn off (LOW) GPIO's on Startup */
	DIGITAL_IO_SetOutputLow(&DIGITAL_IO_0);
	DIGITAL_IO_SetOutputLow(&DIGITAL_IO_1);

	/* Initialize UART_0 (Connected to USB/CDC Interface) */
	UART_STATUS_t init_status;
	init_status = (UART_STATUS_t)UART_Init(&UART_0);
	if (init_status != UART_STATUS_SUCCESS) {
	  XMC_DEBUG("DAVE UART_0 Initialization Failed!\n");
	} else {
	  if (UART_Transmit(&UART_0, UART0_mesg, sizeof(UART0_mesg)) == UART_STATUS_SUCCESS) {
	     while(UART_0.runtime->tx_busy) {
	     }
	  }
	}

	/*-----------------------------------------------------*/
	/* start up the ARM RTX RTOS                           */
	/* NOTE: Increase the default number of threads...     */
	/*       if you want more than 4 (default)             */
	/*       If you experience problems using "printf",etc.*/
    /*       then increase the default thread stack size   */
	/*       i.e. (200 -> 512 bytes)                       */
	/*-----------------------------------------------------*/
	osThreadCreate(osThread(thread_task_1), NULL);
	osThreadCreate(osThread(thread_task_2), NULL);
	osThreadCreate(osThread(thread_task_3), NULL);
	osThreadCreate(osThread(thread_task_4), NULL);
	osKernelStart();
	/*-----------------------------------------------------*/
    /* the RTX RTOS takes over now, main doesn't return... */
	/*-----------------------------------------------------*/
	  while (1) {
	    osDelay(1000);
	  }
  }
} /* End of main() */
