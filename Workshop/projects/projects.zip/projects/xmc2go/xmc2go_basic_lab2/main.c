/**
 *  File :     main.c
 *  Date:      2015 Sep 26 15:38:38
 *  Author:    Tom Moxon
 *  Copyright: PatternAgents, LLC
 *
 *  DAVE_Workshop Basic Lab2
 *  <br>
 *  In the second lab, we will add two (2) PWM APPs in addition to the
 *  DIGITAL_IO APPs (i.e. GPIO pins) and assign these to physical ports,
 *  PORT1_0 and PORT1_1, which drive LED1 and LED2, respectively.
 *  We will set the PWM units at a blink rate of 1Hz and 2Hz respectively.
 *  <br>
 */

/** Include Declarations from the DAVE Code Generator (i.e. the hardware platform) */
#include <DAVE.h>


/**
 * @brief main() - Application entry point
 *
 * <b>Details of function</b><br>
 * This routine is the application entry point. It is invoked by the device startup code. It is responsible for
 * invoking the APP initialization dispatcher routine - DAVE_Init() and hosting the place-holder for user application
 * code.
 * <br>
 */
int main(void)
{
  DAVE_STATUS_t status;

  /** Initialize the DAVE APPs (i.e. the hardware platform) and return status   */
  status = DAVE_Init();

  if(status == DAVE_STATUS_FAILURE)
  {
    /* DAVE/XMCLib Run-Time Error Handler Code.                                 */
	/* The while loop below can be replaced with a user error handler.          */
    XMC_DEBUG("DAVE APPs initialization failed\n");
    while(1U)
    {
    	/* Infinite loop for failed initialization */
    	/* XMC_DEBUG("Dave's not here, man...\n"); */
    }
  } else {
    /* Successful start of the DAVE APPs, go on to running the user application */
    /* Place User Application Code below :                                      */
    while(1U)
    {
      /* main loop is idle - everything is handled in the hardware & DAVE APPs  */
    }
  }
} /* End of main() */
